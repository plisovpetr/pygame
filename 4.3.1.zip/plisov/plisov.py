import pygame

pygame.init()
screen = pygame.display.set_mode((210, 210))
background = pygame.image.load("background.png")
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    screen.blit(background, (0, 0))
    pygame.display.update()
pygame.quit()